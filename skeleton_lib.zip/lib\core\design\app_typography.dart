import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTypography {
  AppTypography._();
  static const headline = TextStyle(
      fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.textPrimary);
  static const title = TextStyle(
      fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textPrimary);
  static const body = TextStyle(fontSize: 16, color: AppColors.textPrimary);
  static const caption =
      TextStyle(fontSize: 12, color: AppColors.textSecondary);
}
