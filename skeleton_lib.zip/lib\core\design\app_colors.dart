import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const primary = Color(0xFF3F51B5);
  static const secondary = Color(0xFF00BFA5);
  static const error = Color(0xFFB00020);
  static const background = Color(0xFFFAFAFA);
  static const surface = Colors.white;
  static const textPrimary = Color(0xFF212121);
  static const textSecondary = Color(0xFF757575);
}
